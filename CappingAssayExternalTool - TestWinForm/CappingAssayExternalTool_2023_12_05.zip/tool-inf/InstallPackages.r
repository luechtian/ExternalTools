install.packages(c("dplyr", "stringr", "tidyr", "purrr", "openxlsx", "ggplot2"), 
                 repos='http://cran.us.r-project.org')