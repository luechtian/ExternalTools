library(dplyr)
library(stringr)
library(tidyr)
library(purrr)
library(openxlsx)

#### Functions ####
parse_conc <- function(string){
  
  string <- stringr::str_remove(string, "Cal ")
  string <- stringr::str_split(string, "_")
  string <- unlist(purrr::map(string, 1))
  string <- stringr::str_replace(string, ",", ".")
  string <- suppressWarnings(as.numeric(string))
  
  
}

parse_samplegroup <- function(string){
  
  remove_tail <- function(string){
    string_tail <- stringr::str_split(string, "_")[[1]] %>% 
      tail(n = 1) %>% 
      paste0("_", .)
    
    str_remove(string, string_tail)
  }
  
  # remove_tail-function is not vectorised. This means the tail of the first element of a vector
  # will be picked for the str_remove-function for all other elements in the same vector.
  # With map() this behaviour can be bypassed, so each element has its own string-tail.
  
  purrr::map(string, remove_tail) %>% 
    unlist() 
  
}

#### Import data ####
metadata <- read.csv(list.files(Sys.getenv("temp"), 
                                pattern = "AssayValidation_01_Metadata_Assay_Validation_metadata.csv",
                                full.names = TRUE),
                     check.names = FALSE) %>%
  tibble()

metadata <- metadata %>%
  mutate(SampleGroup = parse_samplegroup(Replicate),
         `AnalyteConcentration` = parse_conc(Replicate),SampleType = if_else(str_detect(Replicate, "Cal") == TRUE, "Standard", SampleType),
         SampleType = if_else(AnalyteConcentration == 0, "Blank", SampleType),
         SampleType = if_else(str_detect(Replicate, "QC") == TRUE, "Quality Control", SampleType),
         `Sample Input [ul]` = if_else(str_detect(Replicate, "Cal") != TRUE, 200, 0))

write.xlsx(metadata, "metadata.xlsx")
getwd()